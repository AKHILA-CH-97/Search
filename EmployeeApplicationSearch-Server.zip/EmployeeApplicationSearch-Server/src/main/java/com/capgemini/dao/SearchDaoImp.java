package com.capgemini.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.model.SearchEntity;

@Repository
public class SearchDaoImp implements SearchDao {
	
	@Autowired
	SearchRepo srepo;
	
	public List<SearchEntity> search(String Name) {
		
		return srepo.findAllByName(Name);
	}

	

	
}

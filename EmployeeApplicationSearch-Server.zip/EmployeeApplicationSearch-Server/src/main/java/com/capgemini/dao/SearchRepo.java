package com.capgemini.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.model.SearchEntity;

public interface SearchRepo extends JpaRepository<SearchEntity, String> {
	List<SearchEntity> findAllByName(String Name);

}

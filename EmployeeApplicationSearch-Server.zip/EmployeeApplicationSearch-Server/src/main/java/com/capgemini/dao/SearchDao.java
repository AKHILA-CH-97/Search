package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.SearchEntity;

public interface SearchDao  {
	
	public abstract List<SearchEntity> search(String Name);

}

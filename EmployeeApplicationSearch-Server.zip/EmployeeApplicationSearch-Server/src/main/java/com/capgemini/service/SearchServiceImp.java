package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.SearchDao;
import com.capgemini.model.SearchEntity;

@Service
public class SearchServiceImp implements SearchService {

	@Autowired
	SearchDao dao;
	@Override
	public List<SearchEntity> search(String Name) {
		// TODO Auto-generated method stub
		return dao.search(Name);
	}

}

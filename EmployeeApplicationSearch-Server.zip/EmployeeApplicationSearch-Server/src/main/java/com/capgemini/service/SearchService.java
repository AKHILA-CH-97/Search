package com.capgemini.service;

import java.util.List;

import com.capgemini.model.SearchEntity;


public interface SearchService {

	public abstract List<SearchEntity> search(String Name);
	
	
	
}

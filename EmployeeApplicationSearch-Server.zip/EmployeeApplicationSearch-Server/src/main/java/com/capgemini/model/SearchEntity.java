package com.capgemini.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Employee_Details")
public class SearchEntity {
	
	
	private String capgemini_Id;
	@Id
	private String Name;
	private String capgemini_Email;
	private String BU;
	private String Shadow_Project_Name;
	private String Shadow_Project_Mentor;
	private String Task_Description;
	
public String getCapgemini_Id() {
		return capgemini_Id;
	}
	public void setCapgemini_Id(String capgemini_Id) {
		this.capgemini_Id = capgemini_Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCapgemini_Email() {
		return capgemini_Email;
	}
	public void setCapgemini_Email(String capgemini_Email) {
		this.capgemini_Email = capgemini_Email;
	}
	public String getBU() {
		return BU;
	}
	public void setBU(String bU) {
		BU = bU;
	}
	public String getShadow_Project_Name() {
		return Shadow_Project_Name;
	}
	public void setShadow_Project_Name(String shadow_Project_Name) {
		Shadow_Project_Name = shadow_Project_Name;
	}
	public String getShadow_Project_Mentor() {
		return Shadow_Project_Mentor;
	}
	public void setShadow_Project_Mentor(String shadow_Project_Mentor) {
		Shadow_Project_Mentor = shadow_Project_Mentor;
	}
	public String getTask_Description() {
		return Task_Description;
	}
	public void setTask_Description(String task_Description) {
		Task_Description = task_Description;
	}


	@Override
	public String toString() {
		return "SearchEntity [capgemini_Id=" + capgemini_Id + ", Name=" + Name + ", capgemini_Email=" + capgemini_Email
				+ ", BU=" + BU + ", Shadow_Project_Name=" + Shadow_Project_Name + ", Shadow_Project_Mentor="
				+ Shadow_Project_Mentor + ", Task_Description=" + Task_Description + "]";
	}

}

import { Component, NgModule } from '@angular/core';
import { Routes } from '@angular/router';
import {SearchComponent} from './search/search.component';
import {FormsModule} from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})




export class AppComponent {
  title = 'search-filter-download';


}


export const routes:Routes=[{path:'search',component:SearchComponent}]
export class search{

    capgemini_Id : string;
    Name : string;
    capgemini_Email :string;
    BU : string;
    Shadow_Project_Name : string;
    Shadow_Project_Mentor : string;
    Task_Description : string ;     

}
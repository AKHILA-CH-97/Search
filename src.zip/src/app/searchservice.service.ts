import { Injectable } from '@angular/core';
import { SearchComponent } from './search/search.component';

import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError } from "rxjs/operators";
import {search} from './search/search'

@Injectable({
  providedIn: 'root'
})
export class SearchserviceService {
  private baseUrl = 'http://localhost:8083';
  constructor(private http: HttpClient) { }
  search(Name :string):Observable <search>{
    return this.http.get<search>(`${this.baseUrl}`+`/search/`+Name).pipe(catchError(this.errorHandle));
  }
  errorHandle(error: HttpErrorResponse) {
    return throwError(error.message || " Server Error");
  }
}
